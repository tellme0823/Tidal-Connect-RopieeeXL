// vim:ft=javascript:ts=2:sw=2:sts=2:et
"use strict";

process.env.NODE_ENV = process.env.NODE_ENV || 'development';

const hostname = '0.0.0.0';
const port = process.env.NODE_PORT || 3000;
const useAuth = process.env.USE_AUTH || false;
const authPassword = process.env.PASSWORD || 'cGFzc3dvcmQ=';

// define all globals that can differ between brands
var Constants = require('./constants.js');
const GLOBAL_PROD_NAME = process.env.PROD_NAME || Constants.GLOBAL_PROD_NAME;
const GLOBAL_PROD_NAME_XL = process.env.PROD_NAME_XL || Constants.GLOBAL_PROD_NAME_XL;
const GLOBAL_PRODUCT_ICON = Constants.GLOBAL_PRODUCT_ICON;
const GLOBAL_PRODUCT_ICON_XL = Constants.GLOBAL_PRODUCT_ICON_XL;
const GLOBAL_FAVICON = Constants.GLOBAL_FAVICON;
const GLOBAL_SHOW_WELCOME = Constants.GLOBAL_SHOW_WELCOME;
const GLOBAL_SHOW_DONATIONS = Constants.GLOBAL_SHOW_DONATIONS;

const GLOBAL_FOOTER_COPYRIGHT = Constants.GLOBAL_FOOTER_COPYRIGHT;
const GLOBAL_FOOTER_MANUFACTURER = Constants.GLOBAL_FOOTER_MANUFACTURER;
const GLOBAL_FOOTER_URL = Constants.GLOBAL_FOOTER_URL;
const GLOBAL_FOOTER_URL_ALIAS = Constants.GLOBAL_FOOTER_URL_ALIAS;

// menu switches
const GLOBAL_MENU_SHOW_DISPLAY              = Constants.GLOBAL_MENU_SHOW_DISPLAY;
const GLOBAL_MENU_SHOW_REMOTE               = Constants.GLOBAL_MENU_SHOW_REMOTE;
const GLOBAL_MENU_SHOW_ADVANCED             = Constants.GLOBAL_MENU_SHOW_ADVANCED;
const GLOBAL_MENU_SHOW_INFORMATION          = Constants.GLOBAL_MENU_SHOW_INFORMATION;
const GLOBAL_MENU_SHOW_DEVICES              = Constants.GLOBAL_MENU_SHOW_DEVICES;

const GLOBAL_MENU_GENERAL_SHOW_HAT          = Constants.GLOBAL_MENU_GENERAL_SHOW_HAT;
const GLOBAL_MENU_GENERAL_SHOW_USB          = Constants.GLOBAL_MENU_GENERAL_SHOW_USB;
const GLOBAL_MENU_GENERAL_SHOW_RAAT         = Constants.GLOBAL_MENU_GENERAL_SHOW_RAAT;
const GLOBAL_MENU_GENERAL_SHOW_RAAT_DOP     = Constants.GLOBAL_MENU_GENERAL_SHOW_RAAT_DOP;
const GLOBAL_MENU_GENERAL_SHOW_RAAT_SOFTVOL = Constants.GLOBAL_MENU_GENERAL_SHOW_RAAT_SOFTVOL;
const GLOBAL_MENU_GENERAL_SHOW_RAAT_VOLCTRL = Constants.GLOBAL_MENU_GENERAL_SHOW_RAAT_VOLCTRL;

const GLOBAL_MENU_INFO_SHOW_BOARD_INFO      = Constants.GLOBAL_MENU_INFO_SHOW_BOARD_INFO;
const GLOBAL_MENU_INFO_SHOW_SOFTWARE_LIST   = Constants.GLOBAL_MENU_INFO_SHOW_SOFTWARE_LIST;
const GLOBAL_MENU_INFO_SHOW_KERNEL_VER      = Constants.GLOBAL_MENU_INFO_SHOW_KERNEL_VER;

const GLOBAL_MENU_XL_SHOW_UPNP              = Constants.GLOBAL_MENU_XL_SHOW_UPNP;
const GLOBAL_MENU_XL_SHOW_SHAIRPORT         = Constants.GLOBAL_MENU_XL_SHOW_SHAIRPORT;
const GLOBAL_MENU_XL_SHOW_SPOTIFY           = Constants.GLOBAL_MENU_XL_SHOW_SPOTIFY;
const GLOBAL_MENU_XL_SHOW_SQUEEZELITE       = Constants.GLOBAL_MENU_XL_SHOW_SQUEEZELITE;
const GLOBAL_MENU_XL_SHOW_HQPLAYER          = Constants.GLOBAL_MENU_XL_SHOW_HQPLAYER;
const GLOBAL_MENU_XL_SHOW_BLUETOOTH         = Constants.GLOBAL_MENU_XL_SHOW_BLUETOOTH;
const GLOBAL_MENU_XL_SHOW_TIDAL         	= Constants.GLOBAL_MENU_XL_SHOW_TIDAL;

const GLOBAL_MENU_NAME_XL                   = Constants.GLOBAL_MENU_NAME_XL;

// take care of logging
const __logger   = require('./log.js')

const spawn      = require('child_process').spawn;
const spawnSync  = require('child_process').spawnSync;
const os         = require('os');
const crypto     = require('crypto');
const path       = require('path');
const express    = require('express');
const basicAuth  = require('express-basic-auth');
const bodyParser = require('body-parser');
const moment     = require('moment-timezone');
const clone      = require('clone');
const _          = require('underscore');
const printf     = require('printf');
const bonjour    = require('./bonjour');
const config     = require('./config');
const statemgr   = require('./statemgr');
const helpers    = require('./helpers');
const websocket  = require('./websocket');

const apiRouter  = require('./routes/api');

// -------------------------------------------------------------------------------------------
// -------------------------------------------------------------------------------------------
// -------------------------------------------------------------------------------------------

console.log('');
console.log('');
__logger.info('STARTING UP... ' + process.env.NODE_ENV);

// initialise settings and read them immediately
var settings = {};
settings = config.read();
__logger.info('read config: ' + JSON.stringify(settings, null, '  '));

// create session id
const SESSION_ID = Math.random().toString(36).substr(2, 5);
__logger.info('SESSION ID: ' + SESSION_ID);

// check feature toggles
if (typeof settings.FEATURE_TOGGLE_ENABLE_XL === 'undefined') settings['FEATURE_TOGGLE_ENABLE_XL'] = false;
__logger.debug('FEATURE TOGGLE enable_xl: ' + settings.FEATURE_TOGGLE_ENABLE_XL);

const app = express();

app.set('views', './views')
app.set('view engine', 'pug')
app.use('/static', express.static(path.join(__dirname, 'static')))
app.use(bodyParser.urlencoded({
   extended: true
}))
app.use(bodyParser.json());
app.enable('view cache');

// Make some of our objects accessible to our router(s)
app.use(function(req,res,next){
    req.state = state;
    req.wifi = wifi;
    req.session = SESSION_ID;
    next();
});

app.use('/api', apiRouter);

// Should we enable basic authentication?
__logger.debug("enabling basic auth: " + useAuth);
if (useAuth) {
  var passwd = Buffer.from(authPassword, 'base64').toString('ascii');
  __logger.debug('use basic auth password: ' + passwd);

  app.use(basicAuth({
    users: { 'admin': passwd },
    challenge: true,
    realm: 'ropieee',
  }))
}





function load_vars_for_pug(obj) {
   var vars = {}

   var this_vars = {
     'title': 'Welcome',
     'GLOBAL_PROD_NAME': GLOBAL_PROD_NAME,
     'GLOBAL_PROD_NAME_XL': GLOBAL_PROD_NAME_XL,
     'SESSION_ID': SESSION_ID,
     'use_auth': state.use_auth,

     'FEATURE_TOGGLE_ENABLE_XL':                settings.FEATURE_TOGGLE_ENABLE_XL,

     'GLOBAL_FOOTER_COPYRIGHT':                 GLOBAL_FOOTER_COPYRIGHT,
     'GLOBAL_FOOTER_MANUFACTURER':              GLOBAL_FOOTER_MANUFACTURER,
     'GLOBAL_FOOTER_URL':                       GLOBAL_FOOTER_URL,
     'GLOBAL_FOOTER_URL_ALIAS':                 GLOBAL_FOOTER_URL_ALIAS,

     'GLOBAL_MENU_SHOW_DISPLAY':                GLOBAL_MENU_SHOW_DISPLAY,
     'GLOBAL_MENU_SHOW_REMOTE':                 GLOBAL_MENU_SHOW_REMOTE,
     'GLOBAL_MENU_SHOW_ADVANCED':               GLOBAL_MENU_SHOW_ADVANCED,
     'GLOBAL_MENU_SHOW_INFORMATION':            GLOBAL_MENU_SHOW_INFORMATION,
     'GLOBAL_MENU_SHOW_DEVICES':                GLOBAL_MENU_SHOW_DEVICES,

     'GLOBAL_MENU_GENERAL_SHOW_HAT':            GLOBAL_MENU_GENERAL_SHOW_HAT,
     'GLOBAL_MENU_GENERAL_SHOW_USB':            GLOBAL_MENU_GENERAL_SHOW_USB,
     'GLOBAL_MENU_GENERAL_SHOW_RAAT':           GLOBAL_MENU_GENERAL_SHOW_RAAT,
     'GLOBAL_MENU_GENERAL_SHOW_RAAT_DOP':       GLOBAL_MENU_GENERAL_SHOW_RAAT_DOP,
     'GLOBAL_MENU_GENERAL_SHOW_RAAT_SOFTVOL':   GLOBAL_MENU_GENERAL_SHOW_RAAT_SOFTVOL,
     'GLOBAL_MENU_GENERAL_SHOW_RAAT_VOLCTRL':   GLOBAL_MENU_GENERAL_SHOW_RAAT_VOLCTRL,

     'GLOBAL_MENU_INFO_SHOW_BOARD_INFO':        GLOBAL_MENU_INFO_SHOW_BOARD_INFO,
     'GLOBAL_MENU_INFO_SHOW_SOFTWARE_LIST':     GLOBAL_MENU_INFO_SHOW_SOFTWARE_LIST,
     'GLOBAL_MENU_INFO_SHOW_KERNEL_VER':        GLOBAL_MENU_INFO_SHOW_KERNEL_VER,

     'GLOBAL_MENU_XL_SHOW_UPNP':                GLOBAL_MENU_XL_SHOW_UPNP,
     'GLOBAL_MENU_XL_SHOW_SHAIRPORT':           GLOBAL_MENU_XL_SHOW_SHAIRPORT,
     'GLOBAL_MENU_XL_SHOW_SPOTIFY':             GLOBAL_MENU_XL_SHOW_SPOTIFY,
     'GLOBAL_MENU_XL_SHOW_SQUEEZELITE':         GLOBAL_MENU_XL_SHOW_SQUEEZELITE,
     'GLOBAL_MENU_XL_SHOW_HQPLAYER':            GLOBAL_MENU_XL_SHOW_HQPLAYER,
     'GLOBAL_MENU_XL_SHOW_BLUETOOTH':           GLOBAL_MENU_XL_SHOW_BLUETOOTH,
	'GLOBAL_MENU_XL_SHOW_TIDAL':           		GLOBAL_MENU_XL_SHOW_TIDAL,

     'GLOBAL_MENU_NAME_XL':                     GLOBAL_MENU_NAME_XL,

     'GLOBAL_FAVICON':                          GLOBAL_FAVICON,
     'GLOBAL_PRODUCT_ICON':                     GLOBAL_PRODUCT_ICON,
     'GLOBAL_PRODUCT_ICON_XL':                  GLOBAL_PRODUCT_ICON_XL,
     'GLOBAL_SHOW_DONATIONS':                   GLOBAL_SHOW_DONATIONS,

     // XL specific stuff
     'config_rp_this_is_xl':                    settings.rp_this_is_xl,
     'config_rp_xl_shairport_volume_control':   settings.rp_xl_shairport_volume_control,
     'config_rp_xl_shairport_output':           settings.rp_xl_shairport_output,
     'config_rp_xl_upmpdcli_output':            settings.rp_xl_upmpdcli_output,
     'config_rp_xl_upmpdcli_volume_control':    settings.rp_xl_upmpdcli_volume_control,
     'config_rp_xl_upmpdcli_openhome':          settings.rp_xl_upmpdcli_openhome,
     'config_rp_xl_upmpdcli_dop':               settings.rp_xl_upmpdcli_dop,
     'config_rp_xl_spotify_output':             settings.rp_xl_spotify_output,
     'config_rp_xl_spotify_volume_control':     settings.rp_xl_spotify_volume_control,
     'config_rp_xl_spotify_initial_volume':     settings.rp_xl_spotify_initial_volume,
     'config_rp_xl_spotify_username':           settings.rp_xl_spotify_username,
     'config_rp_xl_spotify_password':           settings.rp_xl_spotify_password,
     'config_rp_xl_squeezelite_output':         settings.rp_xl_squeezelite_output,
     'config_rp_xl_squeezelite_volume_control': settings.rp_xl_squeezelite_volume_control,
     'config_rp_xl_squeezelite_dop':            settings.rp_xl_squeezelite_dop,
     'config_rp_xl_hqplayer_output':            settings.rp_xl_hqplayer_output,
     'config_rp_xl_bluetooth_output':           settings.rp_xl_bluetooth_output,
	'config_rp_xl_tidal_output':           		settings.rp_xl_tidal_output,
	
     'config_rp_hostname':                      settings.rp_hostname,
     'config_rp_reboottime':                    settings.rp_reboottime,
     'config_rp_auto_update':                   settings.rp_auto_update,
     'config_rp_reboot_schedule':               settings.rp_reboot_schedule,
     'config_rp_audio':                         settings.rp_audio,
     'config_rp_audio_usb':                     settings.rp_audio_usb,
     'config_rp_audio_usb_autosuspend':         settings.rp_audio_usb_autosuspend,
     'config_rp_audio_alsa_dapm':               settings.rp_audio_alsa_dapm,
     'config_rp_raat_dop_enabled':              settings.rp_raat_dop_enabled,
     'config_rp_raat_software_volume_enabled':  settings.rp_raat_software_volume_enabled,
     'config_rp_raat_volume_control':           settings.rp_raat_volume_control,
     'config_rp_timezone_set':                  settings.rp_timezone,
     'config_rp_touchscreen_detected':          settings.rp_touchscreen_detected,
     'config_rp_touchscreen_orientation':       settings.rp_touchscreen_orientation,
     'config_rp_touchscreen_zone':              settings.rp_touchscreen_zone,
     'config_rp_touchscreen_scrolling':         settings.rp_touchscreen_scrolling,
     'config_rp_touchscreen_blankscreen':       settings.rp_touchscreen_blankscreen,
     'config_rp_touchscreen_screensaver_time':  settings.rp_touchscreen_screensaver_time,
     'config_rp_touchscreen_clockcolor':        settings.rp_touchscreen_clockcolor,
     'config_rp_touchscreen_custom_clockcolor': settings.rp_touchscreen_custom_clockcolor,
     'config_rp_touchscreen_clock24':           settings.rp_touchscreen_clock24,
     'config_rp_touchscreen_hide_pwr_button':   settings.rp_touchscreen_hide_pwr_button,
     'config_rp_touchscreen_hide_opt_buttons':  settings.rp_touchscreen_hide_opt_buttons,
     'config_rp_touchscreen_show_blur_image':   settings.rp_touchscreen_show_blur_image,

     'config_rp_repo':                          settings.rp_repo,
     'config_rp_network_wired_method':          settings.rp_network_wired_method,
     'config_rp_network_wired_ipaddr':          settings.rp_network_wired_ipaddr,
     'config_rp_network_wired_netmask':         settings.rp_network_wired_netmask,
     'config_rp_network_wired_gateway':         settings.rp_network_wired_gateway,
     'config_rp_network_wireless_enabled':      settings.rp_network_wireless_enabled,
     'config_rp_network_wireless_iface':        settings.rp_network_wireless_iface,
     'config_rp_network_wireless_essid':        settings.rp_network_wireless_essid,
     'config_rp_network_wireless_psk':          settings.rp_network_wireless_psk,
     'config_rp_network_wireless_psk2':         settings.rp_network_wireless_psk2,
     'config_rp_remote_control':                settings.rp_remote_control,
     'config_rp_remote_control_zone':           settings.rp_remote_control_zone,
     'config_rp_force_mixer_onstart':           settings.rp_force_mixer_onstart,
     'config_rp_force_mixer_level':             settings.rp_force_mixer_level,
     'config_rp_led_function':                  settings.rp_led_function,
     'config_rp_extension_alarm_clock':         settings.rp_extension_alarm_clock,
     'config_rp_sshd_enabled':                  settings.rp_sshd_enabled,
     'config_rp_web_use_auth':                  settings.rp_web_use_auth,

     'config_rp_network_wireless_networks':     wifi.networks,
     'config_rp_hats':                          audio_devices.hats,

     'config_rp_kernel':                        info.kernel,
     'config_rp_this_hostname':                 info.hostname,
     'config_rp_timezone':                      info.timezone,
     'config_rp_hardware2':                     info.hardware,
     'config_rp_cpu_serial':                    info.cpu_serial,

     'config_rp_needs_reboot':                  state.needs_reboot,
     'config_rp_update_available':              state.update.available,
     'config_rp_update_downloaded':             state.update.downloaded,
     'config_rp_update_finish':                 state.update.finish,
     'config_rp_update_busy':                   state.update.busy,
     'config_rp_version':                       state.version,
     'config_rp_hardware':                      state.hardware,
     'config_rp_usbctrl_fw_version':            state.usbctrl_fw_ver,
     'config_rp_usbctrl_fw_available':          state.usbctrl_fw_available,

     'config_rp_units_size':                    bonjour.units().length
   }

   _.extend(vars, this_vars);
   _.extend(vars, obj);

   return vars;
}

function router(res) {

  // has installation failed?
  if (state.ropieee_install_failed) {
     res.redirect('/install_failed');
     return true;
  }

  // are we updating?
  if ((state.ropieee_init_update) || (state.update.finish)) {
     res.redirect('/init2');
     return true;
  }

  // are we still initialising?
  if (state.ropieee_init) {
     res.redirect('/init2');
     return true;
  }

  // is this our first visit?
  if ((state.visits == 0) && (state.show_welcome) && (GLOBAL_SHOW_WELCOME)) {
    res.redirect('/welcome');
    return true;
  }

  // is a configure running?
  if (state.configure_busy) {
     res.redirect('/configure');
     return true;
  }

  return false;
}

// INSTALL FAILED PAGE
app.get('/install_failed', function(req, res) {
  res.render('install_failed',
    load_vars_for_pug()
  );
});

// INIT PAGE
app.get('/init2', function(req, res) {
  res.render('init2',
    load_vars_for_pug()
  );
});

// WELCOME PAGE
app.get('/welcome', function(req, res) {
  res.render('welcome',
    load_vars_for_pug()
  );
});

app.post('/leftwelcome', function(req, res) {
  if (typeof req.body.dont_show === 'undefined') req.body.dont_show='off'
  __logger.info('returning from welcome: ' + req.body.dont_show);
  helpers.persist_show_welcome(req.body.dont_show);
  state.visits++;
  res.redirect('/');
});

// LOGOUT
app.get('/logout', function (req, res) {
  res.status(401).send('Logged out')
});

// MAIN PAGE
app.get('/', function(req, res) {

  if (router(res)) return;
  state.visits++;

  res.render('general',
    load_vars_for_pug()
  );
});

// DISPLAY PAGE
app.get('/display', function(req, res) {

  if (router(res)) return;
  state.visits++;

  res.render('display',
    load_vars_for_pug()
  );
});

// REMOTE CONTROL PAGE
app.get('/remote', function(req, res) {

  if (router(res)) return;
  state.visits++;

  // is there a remote control?
  var remote_control_detected = helpers.detect_remote_control();
  __logger.info("remote_control_detected: " + remote_control_detected);

  res.render('remote',
    load_vars_for_pug({ 'config_rp_remote_control_detected': remote_control_detected }))
});

// NETWORK PAGE
app.get('/network', function(req, res) {
	
  if (router(res)) return;
  state.visits++;

  var network_config = {};
  network_config = helpers.get_active_network_config();

// DEBUG DATA
//wifi.enabled = true;
//wifi.is_available = true;
//wifi.networks = [ 'klote', 'zooi', 'hierodan', 'c:/virus.exe' ];
//network_config = {
//   "wired": {
//      address: '192.168.1.1',
//      netmask: '255.255.255.0',
//      broadcast: '192.168.1.255',
//      macaddr: 'a:b:c:d'
//   },
//   "wireless": {
//      driver: 'rtl8xxxu',
//      address: '192.168.100.1',
//      netmask: '255.255.252.0',
//      broadcast: '192.168.100.255',
//      macaddr: 'w:x:y:z'
//   },
//   "default_gw": "192.168.1.1"
//}
// END DEBUG DATA

  __logger.debug("network config: " + JSON.stringify(network_config, null, '  '));
  if (network_config != null) __logger.debug("default gw: " + network_config.default_gw);

  let wifi_driver = 'unknown';

  // if we've got wifi, we want to report the used driver
  if (network_config != null && network_config.wireless != null) {
    __logger.debug("wifi driver: " + network_config.wireless.driver);

    if (network_config.wireless.driver == 'brcmfmac') wifi_driver = 'internal';
    else                                              wifi_driver = 'external';
  }

  // let's decode the psk
  let psk = settings.rp_network_wireless_psk2;
  if (psk.length > 0) {
     __logger.debug("found base64 encoded psk: " + settings.rp_network_wireless_psk2);
     psk = Buffer.from(settings.rp_network_wireless_psk2, 'base64').toString('ascii');
     __logger.debug("decoded psk: " + psk);
  }

  res.render('network',
    load_vars_for_pug({ 'config_rp_network_is_wifi_available':  wifi.is_available,
                        'config_rp_network_wireless_iface':     settings.rp_network_wireless_iface,
                        'config_rp_network_wireless_psk2':      psk,
                        'config_rp_network_wireless_driver':    wifi_driver,
                        'config_rp_network_wired_addr':         network_config.wired.address,
                        'config_rp_network_wired_netmask':      network_config.wired.netmask,
                        'config_rp_network_wired_broadcast':    network_config.wired.broadcast,
                        'config_rp_network_wired_macaddr':      network_config.wired.macaddr,

                        'config_rp_network_wireless_addr':      network_config.wireless.address,
                        'config_rp_network_wireless_netmask':   network_config.wireless.netmask,
                        'config_rp_network_wireless_broadcast': network_config.wireless.broadcast,
                        'config_rp_network_wireless_macaddr':   network_config.wireless.macaddr,

                        'config_rp_network_default_gw':         network_config.default_gw })
  );
});

// ADVANCED PAGE
app.get('/advanced', function(req, res) {

  if (router(res)) return;
  state.visits++;

  // let's decode the auth password
  let passwd = settings.rp_web_password;
  if (passwd.length > 0) {
     __logger.debug("found base64 encoded webauth passwd: " + settings.rp_web_password);
     passwd = Buffer.from(settings.rp_web_password, 'base64').toString('ascii');
     __logger.debug("decoded webauth passwd: " + passwd);
  }

  res.render('advanced',
    load_vars_for_pug({ 'config_rp_web_password': passwd })
  );
});

// ROPIEEEXL PAGE
app.get('/ropieeexl', function(req, res) {

  if (router(res)) return;
  state.visits++;

  // find index in hats array to check mixer
  for (var idx in audio_devices.hats) {
    if (audio_devices.hats[idx].id == settings.rp_audio) break;
  }

  if (idx == audio_devices.hats.length) idx = 0;
  var hardware_mixer = audio_devices.hats[idx].hardware_mixer_device;
  __logger.debug('found hardware mixer on current HAT: ' + hardware_mixer);

  // let's decode the Spotify password
  let passwd = settings.rp_xl_spotify_password;
  if (passwd.length > 0) {
     __logger.debug("found base64 encoded Spotify passwd: " + settings.rp_xl_spotify_password);
     passwd = Buffer.from(settings.rp_xl_spotify_password, 'base64').toString('ascii');
     __logger.debug("decoded Spotify passwd: " + passwd);
  }

  res.render('ropieeexl',
    load_vars_for_pug({ 'config_rp_xl_spotify_password': passwd,
                        'hardware_mixer': hardware_mixer })
  );
});

app.get('/info', function(req, res) {

  if (router(res)) return;
  state.visits++;

  // get board temperature
  state.temperature = helpers.get_temperature();

  res.render('info',
    load_vars_for_pug({ 'config_rp_temperature': state.temperature })
  );
});

app.get('/devices', function(req, res) {
  var j = 0;
  var discovered = {};

  for (var value of bonjour.units()) {
    discovered[j] = value;

    // find a proper address (IPv4 for now)
    discovered[j].addr = 'unknown';
    let addr;
    for (addr of discovered[j].addresses) {
       if ((addr.split('.').length - 1) === 3) {
          break;
       }
    }

    discovered[j].addr = addr;

    // is it me you're looking for?
    discovered[j].this_unit = false;
    if (info.ip_addrs.includes(addr)) discovered[j].this_unit = true;

    j++;
  }

  __logger.debug('discovered: ' + JSON.stringify(discovered, null, '  '));

  res.render('devices',
    load_vars_for_pug({ 'config_rp_units': discovered }));
});

app.post('/submit', function(req, res) {
  __logger.info('submitting changes for: ' + req.query.config);

  // if it's not set then just pass through the original value
  if (typeof req.body.ropieee_xl === 'undefined') {
    if (settings.rp_this_is_xl == '1')  req.body.ropieee_xl = 'on';
    if (settings.rp_this_is_xl == '0')  req.body.ropieee_xl = 'off';
  }

  if (typeof req.body.audio_usb === 'undefined')                    req.body.audio_usb='off'
  if (typeof req.body.audio_usb_autosuspend === 'undefined')        req.body.audio_usb_autosuspend='off'
  if (typeof req.body.audio_alsa_dapm === 'undefined')              req.body.audio_alsa_dapm='off'
  if (typeof req.body.raat_dop_enabled === 'undefined')             req.body.raat_dop_enabled='off'
  if (typeof req.body.raat_software_volume_enabled === 'undefined') req.body.raat_software_volume_enabled='off'
  if (typeof req.body.wireless_enabled === 'undefined')             req.body.wireless_enabled='off'
  if (typeof req.body.force_mixer === 'undefined')                  req.body.force_mixer='off'
  if (typeof req.body.alarm_clock === 'undefined')                  req.body.alarm_clock='off'
  if (typeof req.body.sshd_enabled === 'undefined')                 req.body.sshd_enabled='off'
  if (typeof req.body.web_use_auth === 'undefined')                 req.body.web_use_auth='off'
  if (typeof req.body.scrolling === 'undefined')                    req.body.scrolling='off'
  if (typeof req.body.show_clock === 'undefined')                   req.body.show_clock='off'
  if (typeof req.body.clock24 === 'undefined')                      req.body.clock24='off'
  if (typeof req.body.hide_pwr_button === 'undefined')              req.body.hide_pwr_button='off'
  if (typeof req.body.hide_opt_buttons === 'undefined')             req.body.hide_opt_buttons='off'
  if (typeof req.body.show_blur_image === 'undefined')              req.body.show_blur_image='off'
  if (typeof req.body.upmpdcli_openhome === 'undefined')            req.body.upmpdcli_openhome='off'
  if (typeof req.body.upmpdcli_dop === 'undefined')                 req.body.upmpdcli_dop='off'
  if (typeof req.body.squeezelite_dop === 'undefined')              req.body.squeezelite_dop='off'

  if (req.query.config == 'general') {
     __logger.debug('summary for: general');
     __logger.debug('req.body.audio: ' + req.body.audio);

     // find index in hats array
     for (var idx in audio_devices.hats) {
        if (audio_devices.hats[idx].id == req.body.audio) break;
     }

     if (idx == audio_devices.hats.length) idx = 0;
     __logger.debug('hats idx: ' + idx);

     res.render('summary',
       load_vars_for_pug({ 'toggle_rp': 'general',
                           'config_rp_hostname'                     : req.body.hostname,
                           'config_rp_audio'                        : req.body.audio,
                           'config_rp_audio_usb'                    : req.body.audio_usb,
                           'config_rp_raat_dop_enabled'             : req.body.raat_dop_enabled,
                           'config_rp_raat_software_volume_enabled' : req.body.raat_software_volume_enabled,
                           'config_rp_raat_volume_control'          : req.body.raat_volume_control,
                           'config_rp_timezone'                     : req.body.timezone,
                           'config_rp_force_mixer_onstart'          : req.body.force_mixer,
                           'config_rp_force_mixer_level'            : req.body.force_volume,
                           'config_rp_hat'                          : audio_devices.hats[idx].name })
     );
  }

  if (req.query.config == 'display') {
     __logger.debug('summary for: display');
     __logger.debug('show_clock: ' + req.body.show_clock);
     __logger.debug('custom_color: ' + req.body.custom_color);
     __logger.debug('color: ' + req.body.color);

     // if fields are disabled we need to restore the original value
     if (req.body.show_clock == 'off' )                req.body.color        = settings.rp_touchscreen_clockcolor;
     if (typeof req.body.custom_color === 'undefined') req.body.custom_color = settings.rp_touchscreen_custom_clockcolor;

     res.render('summary',
       load_vars_for_pug({ 'toggle_rp': 'display',
                           'config_rp_touchscreen_orientation'       : req.body.orientation,
                           'config_rp_touchscreen_zone'              : req.body.zone,
                           'config_rp_touchscreen_scrolling'         : req.body.scrolling,
                           'show_clock'                              : req.body.show_clock,
                           'config_rp_timezone'                      : req.body.timezone,
                           'config_rp_touchscreen_screensaver_time'  : req.body.timeout,
                           'config_rp_touchscreen_clockcolor'        : req.body.color,
                           'config_rp_touchscreen_custom_clockcolor' : req.body.custom_color,
                           'config_rp_touchscreen_clock24'           : req.body.clock24,
                           'config_rp_touchscreen_hide_pwr_button'   : req.body.hide_pwr_button,
                           'config_rp_touchscreen_hide_opt_buttons'  : req.body.hide_opt_buttons,
                           'config_rp_touchscreen_show_blur_image'   : req.body.show_blur_image })
     );
  }

  if (req.query.config == 'remote') {
     __logger.debug('summary for: remote');
     if (req.body.zone == '') req.body.zone = "unknown";
     res.render('summary',
       load_vars_for_pug({ 'toggle_rp': 'remote',
                           'config_rp_remote_control': req.body.type_remote,
                           'config_rp_remote_control_zone': req.body.zone })
     );
  }

  if (req.query.config == 'network') {
     __logger.debug('summary for: network');
     __logger.debug('network: psk2 = ' + req.body.wireless_psk);
     res.render('summary_network',
       load_vars_for_pug({ 'config_rp_network_is_wifi_available': wifi.is_available,
                           'toggle_rp': 'network',
                           'config_rp_network_wired_method'     : req.body.wired_method,
                           'config_rp_network_wired_ipaddr'     : req.body.wired_ip_addr,
                           'config_rp_network_wired_netmask'    : req.body.wired_netmask,
                           'config_rp_network_wired_gateway'    : req.body.wired_gateway,
                           'config_rp_network_wired_macaddr'    : req.body.wired_macaddr,
                           'config_rp_network_wireless_enabled' : req.body.wireless_enabled,
                           'config_rp_network_wireless_iface'   : req.body.wireless_iface,
                           'config_rp_network_wireless_essid'   : req.body.wireless_essid,
                           'config_rp_network_wireless_psk2'    : req.body.wireless_psk })
     );
  }

  if (req.query.config == 'advanced') {
     __logger.debug('summary for: advanced');
     res.render('summary',
       load_vars_for_pug({ 'toggle_rp': 'advanced',
                           'config_rp_repo'                  : req.body.repo,
                           'config_rp_auto_update'           : req.body.auto_update,
                           'config_rp_reboottime'            : req.body.reboottime,
                           'config_rp_reboot_schedule'       : req.body.reboot_schedule,
                           'config_rp_audio_usb_autosuspend' : req.body.audio_usb_autosuspend,
                           'config_rp_audio_alsa_dapm'       : req.body.audio_alsa_dapm,
                           'config_rp_led_function'          : req.body.led_function,
                           'config_rp_extension_alarm_clock' : req.body.alarm_clock,
                           'config_rp_enable_xl'             : req.body.ropieee_xl,
                           'config_rp_sshd_enabled'          : req.body.sshd_enabled,
                           'config_rp_web_use_auth'          : req.body.web_use_auth,
                           'config_rp_web_password'          : req.body.web_password})
     );
  }

  if (req.query.config == 'ropieeexl') {
     __logger.debug('summary for: ropieeexl');
     res.render('summary',
       load_vars_for_pug({ 'toggle_rp': 'ropieeexl',
                           'config_rp_xl_shairport_volume_control'  : req.body.shairport_volume_control,
                           'config_rp_xl_shairport_output'          : req.body.shairport_output,
                           'config_rp_xl_upmpdcli_output'           : req.body.upmpdcli_output,
                           'config_rp_xl_upmpdcli_volume_control'   : req.body.upmpdcli_volume_control,
                           'config_rp_xl_upmpdcli_openhome'         : req.body.upmpdcli_openhome,
                           'config_rp_xl_upmpdcli_dop'              : req.body.upmpdcli_dop,
                           'config_rp_xl_spotify_output'            : req.body.spotify_output,
                           'config_rp_xl_spotify_volume_control'    : req.body.spotify_volume_control,
                           'config_rp_xl_spotify_initial_volume'    : req.body.spotify_initial_volume,
                           'config_rp_xl_spotify_username'          : req.body.spotify_username,
                           'config_rp_xl_spotify_password'          : req.body.spotify_password,
                           'config_rp_xl_squeezelite_output'        : req.body.squeezelite_output,
                           'config_rp_xl_squeezelite_volume_control': req.body.squeezelite_volume_control,
                           'config_rp_xl_squeezelite_dop'           : req.body.squeezelite_dop,
                           'config_rp_xl_hqplayer_output'           : req.body.hqplayer_output,
                           'config_rp_xl_bluetooth_output'          : req.body.bluetooth_output,
						   'config_rp_xl_tidal_output'              : req.body.tidal_output})
     );
  }
});

app.post('/commit', function( req, res) {
   var copy_settings = {};
   __logger.debug('committing changes for: ' + req.query.config);

   // overrule settings for section general
   if (req.query.config == 'general') {

      if (typeof req.body.force_mixer_level === 'undefined') req.body.force_mixer_level=1

      settings.rp_hostname = req.body.hostname
      if (GLOBAL_MENU_GENERAL_SHOW_HAT) settings.rp_audio = req.body.audio
      if (GLOBAL_MENU_GENERAL_SHOW_USB) {
        settings.rp_audio_usb = req.body.audio_usb
        settings.rp_force_mixer_onstart = req.body.force_mixer
        settings.rp_force_mixer_level = req.body.force_mixer_level
      }
      if (GLOBAL_MENU_GENERAL_SHOW_RAAT) {
        settings.rp_raat_dop_enabled = req.body.raat_dop_enabled
        settings.rp_raat_software_volume_enabled = req.body.raat_software_volume_enabled
        settings.rp_raat_volume_control = req.body.raat_volume_control
      }

      state.needs_reboot = true;
   }

   // overrule settings for section display
   if (req.query.config == 'display') {

      if (typeof req.body.scrolling === 'undefined')  req.body.scrolling  = 'off'
      if (typeof req.body.show_clock === 'undefined') req.body.show_clock = 'off'
      if (typeof req.body.clock24 === 'undefined')    req.body.clock24    = 'off'

      settings.rp_touchscreen_orientation = req.body.orientation
      settings.rp_touchscreen_zone = req.body.zone
      settings.rp_touchscreen_scrolling = req.body.scrolling
      settings.rp_touchscreen_blankscreen = req.body.show_clock
      settings.rp_touchscreen_screensaver_time = req.body.timeout
      settings.rp_touchscreen_clockcolor = req.body.color
      settings.rp_touchscreen_custom_clockcolor = req.body.custom_color
      settings.rp_touchscreen_clock24 = req.body.clock24
      settings.rp_touchscreen_hide_pwr_button = req.body.hide_pwr_button
      settings.rp_touchscreen_hide_opt_buttons = req.body.hide_opt_buttons
      settings.rp_touchscreen_show_blur_image = req.body.show_blur_image

      settings.rp_timezone = req.body.timezone

      // the remote control zone needs to be in sync with the display control zone
      //settings.rp_remote_control_zone = settings.rp_touchscreen_zone

      state.needs_reboot = true;
   }

   // overrule settings for section remote control
   if (req.query.config == 'remote') {
      settings.rp_remote_control = req.body.type_remote 
      settings.rp_remote_control_zone = req.body.zone

      // the display control zone needs to be in sync with the remote control zone
      //settings.rp_touchscreen_zone = settings.rp_remote_control_zone

      state.needs_reboot = true;
   }

   // overrule settings for section network
   if (req.query.config == 'network') {

      if (typeof req.body.wireless_enabled === 'undefined') req.body.wireless_enabled='off'

      settings.rp_network_wired_method  = req.body.wired_method
      settings.rp_network_wired_ipaddr  = req.body.wired_ipaddr
      settings.rp_network_wired_netmask = req.body.wired_netmask
      settings.rp_network_wired_gateway = req.body.wired_gateway

      settings.rp_network_wireless_enabled = req.body.wireless_enabled;
      settings.rp_network_wireless_iface   = req.body.wireless_iface;
      settings.rp_network_wireless_essid   = req.body.wireless_essid;
      wifi.enabled                         = settings.rp_network_wireless_enabled;

      // encode wireless psk
      if (typeof req.body.wireless_psk === 'undefined') req.body.wireless_psk=''
      let psk = Buffer.from(req.body.wireless_psk);
      settings.rp_network_wireless_psk2 = psk.toString('base64');
      __logger.debug("encoding '" + req.body.wireless_psk + "' to: '" + settings.rp_network_wireless_psk2 + "'");

      state.needs_reboot = true;
   }

   // overrule settings for section advanced
   if (req.query.config == 'advanced') {

      if (typeof req.body.ropieee_xl === 'undefined')            req.body.ropieee_xl=settings.rp_this_is_xl
      if (typeof req.body.audio_usb_autosuspend === 'undefined') req.body.audio_usb_autosuspend='off'
      if (typeof req.body.audio_alsa_dapm === 'undefined')       req.body.audio_alsa_dapm='off'
      if (typeof req.body.alarm_clock === 'undefined')           req.body.alarm_clock='off'
      if (typeof req.body.sshd_enabled === 'undefined')          req.body.sshd_enabled='off'
      if (typeof req.body.web_use_auth === 'undefined')          req.body.web_use_auth='off'

      settings.rp_repo                  = req.body.repo
      settings.rp_auto_update           = state.update.interval = req.body.update
      settings.rp_reboottime            = req.body.reboottime
      settings.rp_reboot_schedule       = req.body.reboot_schedule
      settings.rp_audio_usb_autosuspend = req.body.audio_usb_autosuspend
      settings.rp_audio_alsa_dapm       = req.body.audio_alsa_dapm
      settings.rp_led_function          = req.body.led_function
      settings.rp_extension_alarm_clock = req.body.alarm_clock
      settings.rp_this_is_xl            = req.body.ropieee_xl
      settings.rp_sshd_enabled          = req.body.sshd_enabled
      settings.rp_web_use_auth          = req.body.web_use_auth

      // encode web auth password
      if (typeof req.body.web_password === 'undefined') req.body.web_password=''
      let passwd = Buffer.from(req.body.web_password);
      settings.rp_web_password = passwd.toString('base64');
      __logger.debug("encoding '" + req.body.web_password + "' to: '" + settings.rp_web_password + "'");

      state.needs_reboot = true;
   }

   // overrule settings for section XL
   if (req.query.config == 'ropieeexl') {
      settings.rp_xl_shairport_volume_control   = req.body.shairport_volume_control
      settings.rp_xl_shairport_output           = req.body.shairport_output
      settings.rp_xl_upmpdcli_output            = req.body.upmpdcli_output
      settings.rp_xl_upmpdcli_volume_control    = req.body.upmpdcli_volume_control
      settings.rp_xl_upmpdcli_openhome          = req.body.upmpdcli_openhome
      settings.rp_xl_upmpdcli_dop               = req.body.upmpdcli_dop
      settings.rp_xl_spotify_output             = req.body.spotify_output
      settings.rp_xl_spotify_volume_control     = req.body.spotify_volume_control
      settings.rp_xl_spotify_initial_volume     = req.body.spotify_initial_volume
      settings.rp_xl_spotify_username           = req.body.spotify_username
      settings.rp_xl_squeezelite_output         = req.body.squeezelite_output
      settings.rp_xl_squeezelite_volume_control = req.body.squeezelite_volume_control
      settings.rp_xl_squeezelite_dop            = req.body.squeezelite_dop
      settings.rp_xl_hqplayer_output            = req.body.hqplayer_output
      settings.rp_xl_bluetooth_output           = req.body.bluetooth_output
	  settings.rp_xl_tidal_output           	= req.body.tidal_output

      // encode Spotify password
      if (typeof req.body.spotify_password === 'undefined') req.body.spotify_password=''
      let passwd = Buffer.from(req.body.spotify_password);
      settings.rp_xl_spotify_password = passwd.toString('base64');
      __logger.debug("encoding '" + req.body.spotify_password + "' to: '" + settings.rp_xl_spotify_password + "'");

      state.needs_reboot = true;
   }

   // first normalize some stuff
   if (settings.rp_audio_usb == 'on')                         settings.rp_audio_usb=1
   if (settings.rp_audio_usb == 'off')                        settings.rp_audio_usb=0

   if (settings.rp_audio_usb_autosuspend == 'on')             settings.rp_audio_usb_autosuspend=1
   if (settings.rp_audio_usb_autosuspend == 'off')            settings.rp_audio_usb_autosuspend=0

   if (settings.rp_raat_dop_enabled == 'on')                  settings.rp_raat_dop_enabled=1
   if (settings.rp_raat_dop_enabled == 'off')                 settings.rp_raat_dop_enabled=0

   if (settings.rp_raat_software_volume_enabled == 'on')      settings.rp_raat_software_volume_enabled=1
   if (settings.rp_raat_software_volume_enabled == 'off')     settings.rp_raat_software_volume_enabled=0

   if (settings.rp_network_wireless_enabled == 'on')          settings.rp_network_wireless_enabled=1
   if (settings.rp_network_wireless_enabled == 'off')         settings.rp_network_wireless_enabled=0

   if (settings.rp_force_mixer_onstart == 'on')               settings.rp_force_mixer_onstart=1
   if (settings.rp_force_mixer_onstart == 'off')              settings.rp_force_mixer_onstart=0

   if (settings.rp_extension_alarm_clock == 'off')            settings.rp_extension_alarm_clock=0
   if (settings.rp_extension_alarm_clock == 'on')             settings.rp_extension_alarm_clock=1

   if (settings.rp_this_is_xl == 'off')                       settings.rp_this_is_xl=0
   if (settings.rp_this_is_xl == 'on')                        settings.rp_this_is_xl=1

   if (settings.rp_sshd_enabled == 'off')                     settings.rp_sshd_enabled=0
   if (settings.rp_sshd_enabled == 'on')                      settings.rp_sshd_enabled=1

   if (settings.rp_web_use_auth == 'off')                     settings.rp_web_use_auth=0
   if (settings.rp_web_use_auth == 'on')                      settings.rp_web_use_auth=1

   if (settings.rp_touchscreen_scrolling == 'off')            settings.rp_touchscreen_scrolling=0
   if (settings.rp_touchscreen_scrolling == 'on')             settings.rp_touchscreen_scrolling=1

   // careful: this is inverted!
   if (settings.rp_touchscreen_blankscreen == 'off')          settings.rp_touchscreen_blankscreen=1
   if (settings.rp_touchscreen_blankscreen == 'on')           settings.rp_touchscreen_blankscreen=0

   if (settings.rp_touchscreen_clock24 == 'off')              settings.rp_touchscreen_clock24=0
   if (settings.rp_touchscreen_clock24 == 'on')               settings.rp_touchscreen_clock24=1

   if (settings.rp_touchscreen_hide_pwr_button == 'off')      settings.rp_touchscreen_hide_pwr_button=0
   if (settings.rp_touchscreen_hide_pwr_button == 'on')       settings.rp_touchscreen_hide_pwr_button=1

   if (settings.rp_touchscreen_hide_opt_buttons == 'off')     settings.rp_touchscreen_hide_opt_buttons=0
   if (settings.rp_touchscreen_hide_opt_buttons == 'on')      settings.rp_touchscreen_hide_opt_buttons=1

   if (settings.rp_touchscreen_show_blur_image == 'off')      settings.rp_touchscreen_show_blur_image=0
   if (settings.rp_touchscreen_show_blur_image == 'on')       settings.rp_touchscreen_show_blur_image=1

   if (settings.rp_xl_upmpdcli_openhome == 'on')              settings.rp_xl_upmpdcli_openhome=1
   if (settings.rp_xl_upmpdcli_openhome == 'off')             settings.rp_xl_upmpdcli_openhome=0

   if (settings.rp_xl_upmpdcli_dop == 'on')                   settings.rp_xl_upmpdcli_dop=1
   if (settings.rp_xl_upmpdcli_dop == 'off')                  settings.rp_xl_upmpdcli_dop=0

   if (settings.rp_xl_squeezelite_dop == 'on')                settings.rp_xl_squeezelite_dop=1
   if (settings.rp_xl_squeezelite_dop == 'off')               settings.rp_xl_squeezelite_dop=0

   // make a copy
   copy_settings = clone(settings);

   // quotes around some variables
   copy_settings.rp_touchscreen_zone            = '\'' + settings.rp_touchscreen_zone + '\'';
   copy_settings.rp_network_wireless_essid      = '\'' + settings.rp_network_wireless_essid + '\'';
   copy_settings.rp_remote_control_zone         = '\'' + settings.rp_remote_control_zone + '\'';
   copy_settings.rp_xl_upmpdcli_service_name    = '\'' + settings.rp_xl_upmpdcli_service_name + '\'';
   copy_settings.rp_xl_spotify_service_name     = '\'' + settings.rp_xl_spotify_service_name + '\'';
   copy_settings.rp_xl_shairport_service_name   = '\'' + settings.rp_xl_shairport_service_name + '\'';
   copy_settings.rp_xl_squeezelite_service_name = '\'' + settings.rp_xl_squeezelite_service_name + '\'';
   copy_settings.rp_xl_bluetooth_service_name   = '\'' + settings.rp_xl_bluetooth_service_name + '\'';

   var tmpfile2 = config.write_ini(copy_settings);
   __logger.debug('config (ini) written to: ' + tmpfile2);

   // now call configure
   state.configure_busy = true;
   helpers.call_systemd_configure(tmpfile2);

   // and go back home
   res.redirect('/');
});

app.get('/configure', function(req, res) {
   res.render('configure', load_vars_for_pug());
});

app.get('/shutdown', function(req, res) {
   __logger.info('shutting down...');
   res.render('shutdown', load_vars_for_pug());
});

app.get('/reboot', function(req, res) {
   __logger.info('rebooting...');
   res.render('reboot', load_vars_for_pug());
});

app.get('/feedback', function(req, res) {
   res.render('feedback', load_vars_for_pug()); 
});

app.get('/sendfeedback', function(req, res) {
   var d = new Date();
   var str = d.getTime() + os.hostname() + os.uptime();
   var hash = crypto.createHash('sha256');
   hash.update(str);
   var unique = hash.digest('hex').substr(0,16);

   __logger.info('sending feedback...: ' + unique);
   var feedback = spawn('systemctl', ['start', 'ropieee-feedback@' + unique]);

   feedback.stdout.on('data', (data) => {
       __logger.debug(`stdout: ${data}`);
    });

   feedback.stderr.on('data', (data) => {
       __logger.debug(`stderr: ${data}`);
    });

   res.redirect('/feedback_sent?unique=' + unique);
});

app.get('/feedback_sent', function(req, res) {
   __logger.info('feedback sent with unique id: ' + req.query.unique);
   res.render('feedback_sent', load_vars_for_pug({ 'unique': req.query.unique }));
});

app.get('/godown', function(req, res) {
   __logger.info('down down down');
   __logger.debug('type: ' + req.query.reboot);
   var godown;

   if (req.query.reboot) {
      res.render('down', load_vars_for_pug({ 'unique': req.query.unique })); 
      __logger.info('REBOOT');
      if (process.env.NODE_ENV != 'development')
         godown = spawn(path.join(__dirname, 'scripts/reboot'));
   }
   else {
      __logger.info('SHUTDOWN');
      if (process.env.NODE_ENV != 'development')
         godown = spawn(path.join(__dirname, 'scripts/shutdown'));
   }

   godown.stdout.on('data', (data) => {
       __logger.debug(`stdout: ${data}`);
    });

   godown.stderr.on('data', (data) => {
       __logger.debug(`stderr: ${data}`);
    });
});

app.get('/confirm_restart_extension', function(req, res) {
   __logger.debug('restarting remote...');
   res.render('extension', load_vars_for_pug()); 
});

app.get('/restart_extension', function(req, res) {
   __logger.info('restarting RoPieee Remote')
   var remote = spawn('systemctl', ['restart', 'ropieee-remote']);

   remote.stdout.on('data', (data) => {
       __logger.debug(`stdout: ${data}`);
    });

   remote.stderr.on('data', (data) => {
       __logger.debug(`stderr: ${data}`);
    });

    res.redirect('/');
});

// AND FINALLY HANDLE THE REST (404)
app.use(function (req, res, next) {
  res.status(404);

  // respond with html page
  if (req.accepts('html')) {
    res.render('404', { url: req.url });
    return;
  }

  // respond with json
  if (req.accepts('json')) {
    res.send({ error: 'Page Not Found!' });
    return;
  }

  // default to plain-text
  res.type('txt').send('Page Not Found!');
})

// prefill static information
const info = {}
info.hostname = os.hostname();
info.kernel = os.release();
info.timezone = moment.tz.names();
info.hardware = helpers.get_hardware_model2();
info.cpu_serial = helpers.get_cpu_serial();
info.ip_addrs = helpers.this_unit_ip_addr(os.networkInterfaces());

__logger.debug('info: ' + JSON.stringify(info, null, '  '));

// prefill supported HATs
var audio_devices = helpers.read_audio_devices_config();
__logger.info('audio devices config loaded: ' + audio_devices.hats.length);

var state = {}
state.run_mode = process.env.NODE_ENV;
state.ropieee_install_failed = false;
state.ropieee_init = false;
state.ropieee_init_update = false;
state.use_auth = useAuth;
state.needs_reboot = false;
state.about_to_reboot = false;

state.update = {};
state.update.available = false;
state.update.downloaded = false;
state.update.finish = false;
state.update.interval = settings.rp_auto_update;
state.update.busy = false;
state.update.log = '';

state.configure_busy = false;
state.version = 'unknown';
state.hardware = helpers.get_hardware_model();
state.this_is_xl = false;
state.visits = 0;
state.show_welcome = helpers.check_show_welcome();
state.usbctrl_fw_ver = helpers.get_usbctrl_fw_version();
state.usbctrl_fw_available = helpers.is_usbctrl_fw_available();

// DEBUG
//state.hardware = "rpi4";
//state.usbctrl_fw_ver = "0xabcd";
//state.usbctrl_fw_available = true;
//state.use_auth = true;
// END DEBUG

var wifi = {}
wifi.is_available = false
wifi.enabled = false
wifi.networks = new Array();

// first we need to check if wifi is available: can it be enabled at all?
helpers.is_wifi_available(wifi)

// decide if wifi is enabled
//if (settings.rp_network_wireless_enabled == '1' && wifi.is_available) {
//   wifi.enabled = true
//   helpers.get_wifi_networks(wifi)
//}

// is this XL?
if (settings.rp_this_is_xl == '1') {
   state.this_is_xl = true
   __logger.info("THIS IS A XL!");
}

// let's go!
const server = app.listen(port, hostname);
server.keepAliveTimeout = 30 * 1000;
__logger.info("RoPieee Web Server running at http://" + hostname + ":" + port + "/");

// init state manager
statemgr.init(state);

// hook up our websocket server
websocket.init(state);

// hook up bonjour (only if we show the devices tab)
if (GLOBAL_MENU_SHOW_DEVICES) bonjour.init();

// show which version we're running
__logger.info("RoPieee version: " + state.version);

// which hardware?
__logger.info("detected hardware: " + state.hardware);

// USB controller firmware
__logger.info("USB controller firmware: " + state.usbctrl_fw_ver);
__logger.info("USB controller firmware update: " + state.usbctrl_fw_available);

// notify systemd
helpers.call_systemd_notify();

//-----------------------------------------------------------------------------
